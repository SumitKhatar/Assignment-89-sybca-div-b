public class CharArrayToString {
    public static void main(String[] args) {
        char[] nameArray = {'C', 'h', 'a', 't', 'G', 'P', 'T'};
        String nameString = new String(nameArray);
        System.out.println(nameString);
    }
}
