public class MutableToString {
    public static void main(String[] args) {
        StringBuilder stringBuilder = new StringBuilder("Hello, World!");
        String immutableString = stringBuilder.toString();

        System.out.println("Immutable String: " + immutableString);
    }
}
