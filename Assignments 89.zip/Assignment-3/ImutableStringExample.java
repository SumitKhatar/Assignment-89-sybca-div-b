public class ImmutableStringExample {
    public static void main(String[] args) {
        String givenName = "Dipika";
        String fullName = givenName + " Suklan";

        System.out.println("Original Full Name: " + fullName);

        fullName = "Dipika Suklan";

        System.out.println("Corrected Full Name: " + fullName);
    }
}
