public class AverageCalculator {
    public static double calculateAverage(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            sum += num;
        }
        return (double) sum / arr.length;
    }

    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5};
        double average = calculateAverage(arr);
        System.out.println("Average: " + average);
    }
}
