public class StringBuilderMethodsExample {
    public static void main(String[] args) {
        
        StringBuilder stringBuilder = new StringBuilder("Hello, World!");

        stringBuilder.append(" How are you?");
        System.out.println("After append: " + stringBuilder);

        stringBuilder.insert(5, " my dear,");
        System.out.println("After insert: " + stringBuilder);

        stringBuilder.replace(0, 5, "Hi");
        System.out.println("After replace: " + stringBuilder);
)
        stringBuilder.delete(2, 6);
        System.out.println("After delete: " + stringBuilder);

        stringBuilder.reverse();
        System.out.println("After reverse: " + stringBuilder);

        int capacity = stringBuilder.capacity();
        System.out.println("Capacity: " + capacity);

        stringBuilder.ensureCapacity(20);
        System.out.println("After ensureCapacity: " + stringBuilder);

        char charAtIndex = stringBuilder.charAt(0);
        System.out.println("Character at index 0: " + charAtIndex);

        int length = stringBuilder.length();
        System.out.println("Length: " + length);

        String substring1 = stringBuilder.substring(3);
        System.out.println("Substring from index 3: " + substring1);

        String substring2 = stringBuilder.substring(1, 6);
        System.out.println("Substring from index 1 to 6: " + substring2);
    }
}
