public class StringMutabilityConversionExample {
    public static void main(String[] args) {
        
        String immutableString = "Hello, Java!";
        StringBuilder mutableBuilder = new StringBuilder(immutableString);

        System.out.println("Mutable String (converted from String): " + mutableBuilder);

        StringBuffer stringBuffer = new StringBuffer("Hello, World!");
        String immutableFromStringBuffer = stringBuffer.toString();

        System.out.println("Immutable String (converted from StringBuffer): " + immutableFromStringBuffer);
    }
}
