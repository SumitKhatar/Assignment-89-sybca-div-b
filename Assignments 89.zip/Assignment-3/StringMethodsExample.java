public class StringMethodsExample {
    public static void main(String[] args) {
        String str = "Hello, World!";
        
        char charAtIndex = str.charAt(7);
        System.out.println("Character at index 7: " + charAtIndex);

        int strLength = str.length();
        System.out.println("Length of the string: " + strLength);

        String substring = str.substring(7);
        System.out.println("Substring from index 7: " + substring);

        boolean containsHello = str.contains("Hello");
        System.out.println("Contains 'Hello': " + containsHello);

        String anotherString = "Hello, World!";
        boolean isEqual = str.equals(anotherString);
        System.out.println("Strings are equal: " + isEqual);

        boolean isEmpty = str.isEmpty();
        System.out.println("Is the string empty: " + isEmpty);

        String concatenatedString = str.concat(" How are you?");
        System.out.println("Concatenated String: " + concatenatedString);
)
        String replacedString = str.replace('o', '0');
        System.out.println("Replaced String: " + replacedString);

        int indexOfW = str.indexOf('W');
        System.out.println("Index of 'W': " + indexOfW);

        String lowerCaseString = str.toLowerCase();
        System.out.println("Lowercase string: " + lowerCaseString);

        String upperCaseString = str.toUpperCase();
        System.out.println("Uppercase string: " + upperCaseString);

        String stringWithSpaces = "   Trim Me!   ";
        String trimmedString = stringWithSpaces.trim();
        System.out.println("Trimmed string: " + trimmedString);
    }
}
