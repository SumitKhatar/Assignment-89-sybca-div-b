public class StringLengthWithoutLengthMethod {
    public static int getStringLength(String str) {
        int length = 0;
        for(char c : str.toCharArray()) {
            length++;
        }
        return length;
    }

    public static void main(String[] args) {
        String name = "MiuSumire";
        int length = getStringLength(name);
        System.out.println("Length of the string: " + length);
    }
}
