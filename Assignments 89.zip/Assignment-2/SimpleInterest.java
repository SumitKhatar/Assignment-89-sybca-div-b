import java.util.Scanner;

public class SimpleInterest {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Principal, Time (in years), and Rate of Interest (in %) separated by spaces: ");
        double principal = scanner.nextDouble();
        double time = scanner.nextDouble();
        double rate = scanner.nextDouble();

        double simpleInterest = (principal * time * rate) / 100;
        System.out.println("Simple Interest: " + simpleInterest);
    }
}
