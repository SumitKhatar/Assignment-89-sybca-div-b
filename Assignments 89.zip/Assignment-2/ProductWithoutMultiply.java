import java.util.Scanner;

public class ProductWithoutMultiply {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter two numbers separated by spaces: ");
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        int product = 0;
        for (int i = 0; i < Math.abs(b); i++) {
            product += a;
        }

        System.out.println("Product: " + product);
    }
}
