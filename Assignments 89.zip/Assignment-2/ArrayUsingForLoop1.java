public class ArrayUsingForLoop1 {
    public static void main(String[] args) {
        int[] integers = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        float[] floats = {1.1f, 2.2f, 3.3f, 4.4f, 5.5f};
        double[] doubles = {1.11, 2.22, 3.33, 4.44, 5.55, 6.66, 7.77, 8.88};
        short[] shorts = {10, 20, 30, 40};
        byte[] bytes = {1, 2, 3, 4, 5};
        
        for (int i : integers) {
            System.out.print(i + " ");
        }
        System.out.println();
        
        for (float f : floats) {
            System.out.print(f + " ");
        }
        System.out.println();
        
        for (double d : doubles) {
            System.out.print(d + " ");
        }
        System.out.println();
        
        for (short s : shorts) {
            System.out.print(s + " ");
        }
        System.out.println();
        
        for (byte b : bytes) {
            System.out.print(b + " ");
        }
        System.out.println();
    }
}
