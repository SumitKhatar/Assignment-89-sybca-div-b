import java.util.Scanner;

public class EmployeeRecord {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Name, Age, Salary, and Sex separated by spaces: ");
        String name = scanner.next();
        int age = scanner.nextInt();
        double salary = scanner.nextDouble();
        char sex = scanner.next().charAt(0);

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Salary: " + salary);
        System.out.println("Sex: " + sex);
    }
}
