public class ArrayOfDataTypes {
    public static void main(String[] args) {
        int[] integers = new int[10];
        float[] floats = new float[5];
        double[] doubles = new double[8];
        short[] shorts = new short[4];
        byte[] bytes = new byte[5];
    }
}
