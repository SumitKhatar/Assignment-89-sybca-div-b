import java.util.Scanner;

public class RectangleArea {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter length and width of the rectangle separated by spaces: ");
        double length = scanner.nextDouble();
        double width = scanner.nextDouble();

        double area = length * width;
        System.out.println("Area of the rectangle: " + area);
    }
}
