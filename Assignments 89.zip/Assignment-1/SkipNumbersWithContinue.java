public class SkipNumbersWithContinue {
    public static void main(String[] args) {
        for (int i = 1; i <= 10; i++) {
            if (i == 7 || i == 8) {
                continue;
            }
            System.out.print(i + " ");
        }
    }
}
