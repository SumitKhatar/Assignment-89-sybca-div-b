public class GreatestLeastOfThree {
    public static void main(String[] args) {
        int a = 5, b = 10, c = 8;

        int greatest = a > b ? (a > c ? a : c) : (b > c ? b : c);
        int least = a < b ? (a < c ? a : c) : (b < c ? b : c);

        System.out.println("Greatest: " + greatest);
        System.out.println("Least: " + least);
    }
}
