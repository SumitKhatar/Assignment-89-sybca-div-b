public class ProductWithoutMultiply {
    public static void main(String[] args) {
        int a = 5, b = 4;
        int product = 0;

        for (int i = 0; i < b; i++) {
            product += a;
        }

        System.out.println("Product: " + product);
    }
}
