public class Power {
    public static void main(String[] args) {
        int base = 2, exponent = 10;
        int result = (int) Math.pow(base, exponent);
        System.out.println(base + " to the power of " + exponent + " is " + result);
    }
}
