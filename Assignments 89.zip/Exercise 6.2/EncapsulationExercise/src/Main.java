public class Main {
    public static void main(String[] args) {
        // Create two Person objects with different information
        Person person1 = new Person("John", 30, "123 Main St");
        Person person2 = new Person("Alice", 25, "456 Elm St");

        // Display information of both Person objects
        System.out.println("Person 1: Name - " + person1.getName() +
                ", Age - " + person1.getAge() +
                ", Address - " + person1.getAddress());

        System.out.println("Person 2: Name - " + person2.getName() +
                ", Age - " + person2.getAge() +
                ", Address - " + person2.getAddress());

        // Modify the address of person1
        person1.setAddress("789 Oak St");

        // Display updated information of person1
        System.out.println("Updated Address of Person 1: " + person1.getAddress());
    }
}
