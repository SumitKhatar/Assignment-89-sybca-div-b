// Exercise 1
class Student {
    String name;
    int id;

    public static void main(String[] args) {
        Student student = new Student();
        student.name = "John Doe";
        student.id = 12345;
        System.out.println("Name: " + student.name + ", ID: " + student.id);
    }
}

// Exercise 2
class MainClass {
    public static void main(String[] args) {
        Student student = new Student();
        student.name = "Jane Doe";
        student.id = 67890;
        System.out.println("Name: " + student.name + ", ID: " + student.id);
    }
}

// Exercise 3
class Student {
    String name;
    int id;

    public void assignValues(String n, int i) {
        name = n;
        id = i;
    }

    public void displayValues() {
        System.out.println("Name: " + name + ", ID: " + id);
    }
}

// Exercise 4
class Student {
    String name;
    int id;

    public void initialize(String n, int i) {
        name = n;
        id = i;
    }
}

public class Main {
    public static void main(String[] args) {
        Student student = new Student() {
            {
                initialize("John Doe", 12345);
            }
        };
        System.out.println("Name: " + student.name + ", ID: " + student.id);
    }
}

// Exercise 5
class Student {
    String name;
    int id;

    public void initialize(String n, int i) {
        name = n;
        id = i;
    }
}

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student();
        student1.initialize("John Doe", 12345);

        Student student2 = new Student();
        student2.initialize("Jane Doe", 67890);

        System.out.println("Student 1 - Name: " + student1.name + ", ID: " + student1.id);
        System.out.println("Student 2 - Name: " + student2.name + ", ID: " + student2.id);
    }
}

// Exercise 6
class Student {
    String name;
    int id;

    public Student(String n, int i) {
        name = n;
        id = i;
    }

    public void displayValues() {
        System.out.println("Name: " + name + ", ID: " + id);
    }
}

// Exercise 7
class Employee {
    int id;
    String name;
    double salary;

    public void initialize(int i, String n) {
        id = i;
        name = n;
    }
}

public class Main {
    public static void main(String[] args) {
        Employee employee1 = new Employee();
        employee1.initialize(1, "John Doe");
        employee1.salary = 50000.0;

        Employee employee2 = new Employee();
        employee2.initialize(2, "Jane Doe");
        employee2.salary = 60000.0;

        Employee employee3 = new Employee();
        employee3.initialize(3, "Jim Doe");
        employee3.salary = 70000.0;

        System.out.println("Employee 1 - ID: " + employee1.id + ", Name: " + employee1.name + ", Salary: " + employee1.salary);
        System.out.println("Employee 2 - ID: " + employee2.id + ", Name: " + employee2.name + ", Salary: " + employee2.salary);
        System.out.println("Employee 3 - ID: " + employee3.id + ", Name: " + employee3.name + ", Salary: " + employee3.salary);
    }
}

// Exercise 8 (Square)
class Square {
    double side;

    public void initialize(double s) {
        side = s;
    }

    public double calculateArea() {
        return side * side;
    }

    public double calculatePerimeter() {
        return 4 * side;
    }
}

// Exercise 8 (Circle)
class Circle {
    double radius;

    public void initialize(double r) {
        radius = r;
    }

    public double calculateArea() {
        return Math.PI * radius * radius;
    }

    public double calculateCircumference() {
        return 2 * Math.PI * radius;
    }
}

// Exercise 10
class Shape {
    double area;

    public Shape(double side) {
        area = side * side; // For square
    }

    public Shape(double length, double breadth) {
        area = length * breadth; // For rectangle
    }

    public Shape(double base, double height, boolean isTriangle) {
        area = 0.5 * base * height; // For triangle
    }

    public Shape(double radius, boolean isCircle) {
        area = Math.PI * radius * radius; // For circle
    }

    public double getArea() {
        return area;
    }
}

// Exercise 11
class Account {
    double balance;

    public void deposit(double amount) {
        balance += amount;
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful. Remaining balance: " + balance);
        } else {
            System.out.println("Insufficient funds.");
        }
    }

    public double checkBalance() {
        return balance;
    }
}

// Exercise 12
class Student {
    String name;
    int id;
    static String college = "XYZ University";
}

public class Main {
    public static void main(String[] args) {
        Student student1 = new Student();
        student1.name = "John Doe";
        student1.id = 12345;

        Student student2 = new Student();
        student2.name = "Jane Doe";
        student2.id = 67890;

        System.out.println("Student 1 - Name: " + student1.name + ", ID: " + student1.id + ", College: " + Student.college);
        System.out.println("Student 2 - Name: " + student2.name + ", ID: " + student2.id + ", College: " + Student.college);
    }
}

// Exercise 13
class MyClass {
    static int count = 0;

    public MyClass() {
        count++;
    }

    public static void printCount() {
        System.out.println("Number of objects created: " + count);
    }
}

public class Main {
    public static void main(String[] args) {
        MyClass obj1 = new MyClass();
        MyClass obj2 = new MyClass();
        MyClass obj3 = new MyClass();

        MyClass.printCount();
    }
}

// Exercise 14
class Student {
    static String college = "ABC University";
}

public class Main {
    public static void main(String[] args) {
        System.out.println("Original College: " + Student.college);
        Student.college = "XYZ University";
        System.out.println("Updated College: " + Student.college);
    }
}

// Exercise 15
class Triangle {
    static double calculateArea(double base, double height) {
        return 0.5 * base * height;
    }
}

// Exercise 16
class HelloWorld {
    static {
        System.out.println("Hello World");
    }
}

public
