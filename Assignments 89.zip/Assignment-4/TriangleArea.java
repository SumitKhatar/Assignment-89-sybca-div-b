class TriangleArea {
    static double calculateArea(double base, double height) {
        return 0.5 * base * height;
    }
}

public class Main {
    public static void main(String[] args) {
        double base = 5.0;
        double height = 7.0;
        double area = Triangle.calculateArea(base, height);

        System.out.println("Area of the triangle: " + area);
    }
}
