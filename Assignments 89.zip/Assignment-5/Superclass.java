class Superclass {
    int num;

    Superclass(int num) {
        this.num = num;
    }

    void display() {
        System.out.println("Number: " + num);
    }
}

class Subclass extends Superclass {
    Subclass(int num) {
        super(num);
    }
}

public class Main {
    public static void main(String[] args) {
        Subclass obj = new Subclass(42);
        obj.display(); 
    }
}
